import { useEffect, useRef, useState, type FormEvent, type KeyboardEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Activity, AudioLines, Command, Info, Menu, Plus, Pencil, Mic, MicOff, Send, Settings2, Shield, Trash2, Volume2, X,BookOpen, MessageSquare, Code, Folder } from 'lucide-react';
import { useGetJarvisStatus, useSendJarvisChatMessage } from '@workspace/api-client-react';
import {
  Link,
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

type ChatMessage = { id: string; role: 'user' | 'assistant'; text: string; time: number; source?: 'ai' | 'demo' };
type AssistantSettings = { speechEnabled: boolean; speechRate: number; voiceURI: string };
type BrowserRecognition = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((event: { resultIndex: number; results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onerror: ((event: { error: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
};

const CHAT_KEY = 'jarvis-chat-v1';
const THREADS_KEY = 'jarvis-threads-v1';
const ACTIVE_THREAD_KEY = 'jarvis-active-thread-v1';
type ChatThread = { id: string; title: string; messages: ChatMessage[]; updatedAt: number };
const initialThreads = (): ChatThread[] => {
  const saved = readStorage<ChatThread[]>(THREADS_KEY, []);
  if (Array.isArray(saved) && saved.length) return saved;
  const oldMessages = readStorage<ChatMessage[]>(CHAT_KEY, []);
  return [{ id: makeId(), title: oldMessages.length ? 'Первый диалог' : 'Новый чат', messages: oldMessages, updatedAt: Date.now() }];
};

function JarvisBudgetIndicator() {
  const [spent, setSpent] = useState<number | null>(null);

  useEffect(() => {
    let active = true;

    fetch("/api/jarvis/budget")
      .then(async response => {
        if (!response.ok) throw new Error("Budget unavailable");
        return response.json();
      })
      .then(data => {
        if (active) setSpent(Number(data.spentUsd));
      })
      .catch(() => {});

    return () => { active = false; };
  }, []);

  if (spent === null || !Number.isFinite(spent)) return null;

  const percent = Math.min(100, Math.max(0, spent / 5 * 100));

  return (
    <div style={{ padding: 12, borderRadius: 12, border: "1px solid #555", margin: 12 }}>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <strong>Бюджет JARVIS</strong>
        <span>${spent.toFixed(2)} / $5.00</span>
      </div>
      <div style={{ height: 7, background: "#333", borderRadius: 8, marginTop: 10 }}>
        <div style={{
          width: `${percent}%`,
          height: "100%",
          background: spent >= 5 ? "#ef4444" : spent >= 4 ? "#f59e0b" : "#22c55e",
          borderRadius: 8
        }} />
      </div>
      <small>Мягкий лимит — JARVIS продолжит работать после $5</small>
    </div>
  );
}

const SETTINGS_KEY = 'jarvis-settings-v1';
const defaultSettings: AssistantSettings = { speechEnabled: true, speechRate: 1, voiceURI: '' };
const readStorage = <T,>(key: string, fallback: T): T => {
  try {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) as T : fallback;
  } catch {
    return fallback;
  }
};
const speechRecognitionConstructor = () => {
  const scope = window as Window & { SpeechRecognition?: new () => BrowserRecognition; webkitSpeechRecognition?: new () => BrowserRecognition };
  return scope.SpeechRecognition ?? scope.webkitSpeechRecognition;
};
const makeId = () => `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
const getChatErrorMessage = (error: unknown) => {
  if (error && typeof error === 'object' && 'data' in error) {
    const data = (error as { data?: { error?: { message?: unknown } } }).data;
    if (typeof data?.error?.message === 'string') return data.error.message;
  }
  return 'Не удалось получить ответ. Проверьте подключение к серверу и попробуйте ещё раз.';
};

function AppFrame({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return (
    <div className="app-shell">
      <header className="topbar">
        <Link href="/" className="brand" data-testid="link-home" aria-label="JARVIS — на главную">
          <span className="brand-mark"><Command aria-hidden="true" /></span>
          <span>JARVIS<span className="brand-sub">ПЕРСОНАЛЬНЫЙ ПОМОЩНИК</span></span>
        </Link>
        <nav className="top-actions" aria-label="Основная навигация">
          <Link href="/" className="icon-link" aria-current={location === '/' ? 'page' : undefined} data-testid="link-chat">
            <Activity aria-hidden="true" /><span>Диалог</span>
          </Link>
      <JarvisBudgetIndicator />
          <Link href="/settings" className="icon-link" aria-current={location === '/settings' ? 'page' : undefined} data-testid="link-settings">
            <Settings2 aria-hidden="true" /><span>Настройки</span>
          </Link>
        </nav>
      </header>
      <main className="main-area">{children}</main>
      <footer className="settings-footer">
        <span className="footer-left"><span className="footer-mark">J.</span> ЛИЧНЫЙ ПРОТОТИП</span>
        <span>ИСТОРИЯ СОХРАНЯЕТСЯ НА ЭТОМ УСТРОЙСТВЕ</span>
      </footer>
    </div>
  );
}

function Home() {
  const [threads, setThreads] = useState<ChatThread[]>(initialThreads);
  const [activeId, setActiveId] = useState<string>(() => {
    const stored = readStorage<string>(ACTIVE_THREAD_KEY, '');
    const saved = readStorage<ChatThread[]>(THREADS_KEY, []);
    return saved.some(t => t.id === stored) ? stored : '';
  });
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const activeThread = threads.find(t => t.id === activeId) ?? threads[0];
  const currentThreadId = activeThread.id;
  const messages = activeThread.messages;
  const setMessages = (update: ChatMessage[] | ((previous: ChatMessage[]) => ChatMessage[])) => {
    setThreads(previous => previous.map(t => t.id === currentThreadId ? {
      ...t, messages: typeof update === 'function' ? update(t.messages) : update, updatedAt: Date.now(),
    } : t));
  };
  const cancelPending = () => { requestSequence.current += 1; sending.current = false; chatMutation.reset(); setChatError(null); };
  const switchThread = (id: string) => { cancelPending(); setActiveId(id); setSidebarOpen(false); setDraft(''); };
  const newThread = () => {
    cancelPending();
    const thread: ChatThread = { id: makeId(), title: 'Новый чат', messages: [], updatedAt: Date.now() };
    setThreads(prev => [thread, ...prev]); setActiveId(thread.id); setSidebarOpen(false); setDraft('');
  };
  const renameThread = (id: string) => {
    const thread = threads.find(t => t.id === id);
    const title = window.prompt('Название чата', thread?.title ?? '');
    if (title?.trim()) setThreads(prev => prev.map(t => t.id === id ? { ...t, title: title.trim() } : t));
  };
  const deleteThread = (id: string) => {
    if (!window.confirm('Удалить этот чат?')) return;
    cancelPending();
    const remaining = threads.filter(t => t.id !== id);
    if (!remaining.length) { const fresh = { id: makeId(), title: 'Новый чат', messages: [], updatedAt: Date.now() }; setThreads([fresh]); setActiveId(fresh.id); }
    else { setThreads(remaining); if (currentThreadId === id) setActiveId(remaining[0].id); }
  };
  const [settings, setSettings] = useState<AssistantSettings>(() => ({ ...defaultSettings, ...readStorage<AssistantSettings>(SETTINGS_KEY, defaultSettings) }));
  const [draft, setDraft] = useState('');
  const [chatError, setChatError] = useState<string | null>(null);
  const [listening, setListening] = useState(false);
  const [voiceStatus, setVoiceStatus] = useState<{ text: string; error?: boolean } | null>(null);
  const [showClear, setShowClear] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(false);
  const recognition = useRef<BrowserRecognition | null>(null);
  const threadEnd = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const requestSequence = useRef(0);
  const sending = useRef(false);
  const chatMutation = useSendJarvisChatMessage();
  const aiStatusQuery = useGetJarvisStatus();
  const [location] = useLocation();

  useEffect(() => { localStorage.setItem(THREADS_KEY, JSON.stringify(threads)); }, [threads]);
  useEffect(() => { localStorage.setItem(ACTIVE_THREAD_KEY, JSON.stringify(currentThreadId)); }, [currentThreadId]);
  useEffect(() => { localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); }, [settings]);
  useEffect(() => {
    setSpeechSupported(Boolean(speechRecognitionConstructor()));
    return () => { recognition.current?.stop(); window.speechSynthesis?.cancel(); };
  }, []);
  useEffect(() => { threadEnd.current?.scrollIntoView({ behavior: 'smooth', block: 'end' }); }, [messages]);
  useEffect(() => {
    const key = (event: globalThis.KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') {
        event.preventDefault();
        textareaRef.current?.form?.requestSubmit();
      }
      if (event.key === 'Escape') setShowClear(false);
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, []);

  const submitMessage = async (event: FormEvent) => {
    event.preventDefault();
    const text = draft.trim();
    if (!text || sending.current) return;
    sending.current = true;
    const userMessage: ChatMessage = { id: makeId(), role: 'user', text, time: Date.now(), source: 'ai' };
    const requestId = ++requestSequence.current;
    const context = [
      ...messages
        .filter(message => message.source === 'ai')
        .map(message => ({ role: message.role, content: message.text })),
      { role: 'user' as const, content: text },
    ].slice(-20);
    setMessages(current => [...current, userMessage]);
    if (!messages.length) setThreads(prev => prev.map(t => t.id === currentThreadId && t.title === 'Новый чат' ? { ...t, title: text.slice(0, 42) } : t));
    setDraft('');
    setChatError(null);
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
    try {
      const result = await chatMutation.mutateAsync({ data: { messages: context } });
      if (requestId !== requestSequence.current) return;
      const answer: ChatMessage = { id: makeId(), role: 'assistant', text: result.text, time: Date.now(), source: 'ai' };
      setMessages(current => [...current, answer]);
      if (settings.speechEnabled) speak(answer.text);
    } catch (error) {
      if (requestId !== requestSequence.current) return;
      setChatError(getChatErrorMessage(error));
      setDraft(text);
      requestAnimationFrame(() => textareaRef.current?.focus());
    } finally {
      if (requestId === requestSequence.current) sending.current = false;
    }
  };

  const speak = (text: string) => {
    if (!('speechSynthesis' in window)) {
      setVoiceStatus({ text: 'Озвучивание не поддерживается этим браузером.', error: true });
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'ru-RU';
    utterance.rate = settings.speechRate;
    const voice = window.speechSynthesis.getVoices().find(item => item.voiceURI === settings.voiceURI);
    if (voice) utterance.voice = voice;
    utterance.onerror = () => setVoiceStatus({ text: 'Не удалось воспроизвести речь. Проверьте настройки браузера.', error: true });
    utterance.onend = () => setVoiceStatus(null);
    window.speechSynthesis.speak(utterance);
    setVoiceStatus({ text: 'Воспроизвожу ответ на русском языке.' });
  };

  const toggleListening = () => {
    if (listening) {
      recognition.current?.stop();
      setListening(false);
      return;
    }
    const Constructor = speechRecognitionConstructor();
    if (!Constructor) {
      setVoiceStatus({ text: 'Голосовой ввод не поддерживается. Попробуйте Chrome на Android или введите сообщение вручную.', error: true });
      return;
    }
    setVoiceStatus(null);
    const instance = new Constructor();
    instance.lang = 'ru-RU';
    instance.continuous = false;
    instance.interimResults = false;
    instance.onresult = event => {
      const transcript = Array.from({ length: event.results.length }, (_, index) => event.results[index][0]?.transcript ?? '').join(' ').trim();
      if (transcript) {
        setDraft(value => `${value}${value ? ' ' : ''}${transcript}`);
        setVoiceStatus({ text: 'Речь распознана. Проверьте текст и отправьте сообщение.' });
      }
    };
    instance.onerror = event => {
      setListening(false);
      const errors: Record<string, string> = {
        'not-allowed': 'Доступ к микрофону запрещён. Разрешите его в настройках браузера.',
        'service-not-allowed': 'Служба распознавания речи недоступна. Введите сообщение вручную.',
        'no-speech': 'Речь не обнаружена. Попробуйте ещё раз.',
        'audio-capture': 'Микрофон не найден или занят другим приложением.',
        network: 'Не удалось подключиться к службе распознавания. Проверьте интернет.',
      };
      setVoiceStatus({ text: errors[event.error] ?? `Не удалось распознать речь (${event.error}). Попробуйте ввести сообщение.`, error: true });
    };
    instance.onend = () => setListening(false);
    recognition.current = instance;
    try {
      instance.start();
      setListening(true);
      setVoiceStatus({ text: 'Слушаю… Говорите по-русски.' });
    } catch {
      setListening(false);
      setVoiceStatus({ text: 'Не удалось запустить микрофон. Проверьте разрешения браузера.', error: true });
    }
  };

  const resizeDraft = (value: string) => {
    setDraft(value);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 150)}px`;
    }
  };
  const formatTime = (time: number) => new Intl.DateTimeFormat('ru-RU', { hour: '2-digit', minute: '2-digit' }).format(time);

  return (
    <AppFrame>
      {location === '/' ? (
        <section className="chat-page" aria-label="Диалог с JARVIS">
          <div className="jarvis-chat-actions">
            <button type="button" onClick={() => setSidebarOpen(true)} aria-label="Открыть историю чатов"><Menu size={19} /> Чаты</button>
            <button type="button" onClick={newThread}><Plus size={19} /> Новый чат</button>
          </div>
          <div className="hero-intro">
            <div className="eyebrow"><span className="live-dot" style={{ display: 'inline-block', marginRight: 8 }} />{aiStatusQuery.data?.configured ? 'СИСТЕМА ГОТОВА · DEEPSEEK FLASH' : aiStatusQuery.isError ? 'СВЯЗЬ С СЕРВЕРОМ НЕ УДАЛАСЬ' : 'ИИ НЕ ПОДКЛЮЧЁН · ТРЕБУЕТСЯ НАСТРОЙКА'}</div>
            <h1 className="hero-title">Я здесь. С чего начнём?</h1>
            <p className="hero-copy" data-testid="text-ai-disclaimer">{aiStatusQuery.data?.configured ? 'Напишите сообщение или задайте вопрос голосом. Ответы формирует подключённая модель ИИ.' : 'Напишите сообщение или задайте вопрос голосом. Ответы появятся после настройки серверного ключа ИИ.'}</p>
          </div>
          <div className={`ai-connection-banner ${aiStatusQuery.data?.configured ? 'connected' : 'missing'}`} role="status" data-testid="status-ai-connection">
            <span className={`connection-indicator ${aiStatusQuery.data?.configured ? 'on' : ''}`} aria-hidden="true" />
            <div>
              <strong>{aiStatusQuery.data?.configured ? 'ИИ подключён' : aiStatusQuery.isError ? 'Не удалось проверить подключение' : 'Реальные ответы пока недоступны'}</strong>
              <p>{aiStatusQuery.data?.configured
                 ? 'Запросы отправляются в DeepSeek API; секретный ключ хранится только на сервере.'
                : aiStatusQuery.isError
                  ? 'Проверьте запуск API Server и обновите страницу.'
                   : 'Добавьте DEEPSEEK_API_KEY в Tools → Setup → Secrets и перезапустите API Server. Запросы оплачиваются по тарифам DeepSeek API.'}</p>
              {!aiStatusQuery.data?.configured && !aiStatusQuery.isError && (
                 <small>DeepSeek Flash: $0,15 за 1 млн входных токенов без кэш-попадания и $0,60 за 1 млн выходных вне пиковых часов. <a href="https://api-docs.deepseek.com/quick_start/pricing" target="_blank" rel="noreferrer">Актуальные тарифы DeepSeek</a></small>
              )}
            </div>
          </div>
          <div className="core-stage" aria-label="Визуализация ядра JARVIS">
            <span className="system-readout left">ЛОКАЛЬНЫЙ ИНТЕРФЕЙС · 01</span>
            <div className="core-halo" aria-hidden="true">
              <div className="core-orbit" />
              <div className="core-disc"><span className="core-glyph">J.</span></div>
              <span className="core-caption">{aiStatusQuery.data?.configured ? 'JARVIS / ИИ ОНЛАЙН' : 'JARVIS / ОЖИДАЕТ НАСТРОЙКУ'}</span>
            </div>
            <span className="system-readout right">{aiStatusQuery.data?.configured ? 'DEEPSEEK · FLASH' : 'СЕРВИС ИИ НЕ ПОДКЛЮЧЁН'}</span>
          </div>

          <div className="chat-thread" role="log" aria-live="polite" aria-label="История диалога" data-testid="content-chat-history">
            {messages.map(message => (
              <article className={`message ${message.role}`} key={message.id} data-testid={`message-${message.role}-${message.id}`}>
                <div className="message-meta">
                  <span>{message.role === 'user' ? 'ВЫ' : message.source === 'ai' ? 'JARVIS · ИИ' : 'JARVIS · ДЕМО'}</span>
                  {message.role === 'assistant' && <span className="demo-badge">{message.source === 'ai' ? 'ИИ' : 'ДЕМО · НЕ ИИ'}</span>}
                  <time dateTime={new Date(message.time).toISOString()}>{formatTime(message.time)}</time>
                </div>
                <div className="message-body">{message.text}</div>
                {message.role === 'assistant' && (
                  <div className="message-tools">
                    <button className="mini-action" onClick={() => speak(message.text)} aria-label="Озвучить ответ" data-testid={`button-speak-${message.id}`}>
                      <Volume2 aria-hidden="true" />Озвучить
                    </button>
                  </div>
                )}
              </article>
            ))}
            {chatMutation.isPending && <div className="message assistant message-pending" role="status" data-testid="status-ai-thinking">JARVIS формирует ответ…</div>}
            <div ref={threadEnd} />
          </div>
          <div className="composer-wrap">
            <form className="composer" onSubmit={submitMessage} aria-label="Новое сообщение">
              <textarea
                ref={textareaRef}
                value={draft}
                onChange={event => resizeDraft(event.target.value)}
                onKeyDown={(event: KeyboardEvent<HTMLTextAreaElement>) => {
                  if (event.key === 'Enter' && !event.shiftKey) {
                    event.preventDefault();
                    event.currentTarget.form?.requestSubmit();
                  }
                }}
                placeholder="Напишите сообщение…"
                aria-label="Ваше сообщение"
                rows={1}
                data-testid="input-message"
              />
              <div className="compose-tools">
                <button type="button" className={`tool-button ${listening ? 'active' : ''}`} onClick={toggleListening} aria-label={listening ? 'Остановить голосовой ввод' : 'Начать голосовой ввод'} aria-pressed={listening} data-testid="button-microphone">
                  {listening ? <MicOff aria-hidden="true" /> : <Mic aria-hidden="true" />}
                </button>
                <button className="send-button" type="submit" disabled={!draft.trim() || chatMutation.isPending} aria-label={chatMutation.isPending ? 'Ожидание ответа' : 'Отправить сообщение'} data-testid="button-send">
                  {chatMutation.isPending ? <span className="send-spinner" aria-hidden="true" /> : <Send aria-hidden="true" />}
                </button>
              </div>
            </form>
            {chatError && <div className="voice-status error" role="alert" data-testid="status-chat-error">
              <Info aria-hidden="true" />{chatError}
              <button className="mini-action" onClick={() => setChatError(null)} aria-label="Скрыть сообщение об ошибке" data-testid="button-dismiss-chat-error"><X /></button>
            </div>}
            {voiceStatus && <div className={`voice-status ${voiceStatus.error ? 'error' : ''}`} role={voiceStatus.error ? 'alert' : 'status'} data-testid="status-voice">
              {voiceStatus.error ? <Info aria-hidden="true" /> : <AudioLines aria-hidden="true" />}{voiceStatus.text}
              <button className="mini-action" onClick={() => setVoiceStatus(null)} aria-label="Скрыть сообщение о голосе" data-testid="button-dismiss-voice"><X /></button>
            </div>}
            <div className="composer-foot">
              <span className="composer-hint"><span className="live-dot" />{speechSupported ? 'ГОЛОСОВОЙ ВВОД ДОСТУПЕН' : 'ГОЛОСОВОЙ ВВОД МОЖЕТ БЫТЬ НЕДОСТУПЕН'}</span>
              <span>ENTER — ОТПРАВИТЬ · SHIFT + ENTER — НОВАЯ СТРОКА</span>
            </div>
          </div>
        </section>
      ) : (
        <SettingsPage settings={settings} setSettings={setSettings} messages={messages} onClear={() => setShowClear(true)} aiConfigured={aiStatusQuery.data?.configured} />
      )}
      {sidebarOpen && <div className="jarvis-sidebar-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) setSidebarOpen(false); }}>
        <aside className="jarvis-sidebar" aria-label="История чатов">
          <div className="jarvis-sidebar-header"><strong>Мои чаты</strong><button onClick={() => setSidebarOpen(false)} aria-label="Закрыть"><X size={20} /></button></div>
          <button className="jarvis-new-chat" onClick={newThread}><Plus size={18} /> Новый чат</button>
          <div className="jarvis-thread-list">{[...threads].sort((a,b) => b.updatedAt-a.updatedAt).map(t => (
            <div className={`jarvis-thread-item ${t.id === currentThreadId ? 'selected' : ''}`} key={t.id}>
              <button className="jarvis-thread-title" onClick={() => switchThread(t.id)}><MessageSquare size={16} /><span>{t.title}</span></button>
              <button onClick={() => renameThread(t.id)} aria-label="Переименовать"><Pencil size={15} /></button>
              <button onClick={() => deleteThread(t.id)} aria-label="Удалить"><Trash2 size={15} /></button>
            </div>
          ))}</div>
        </aside>
      </div>}
      {showClear && <div className="clear-confirm" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) setShowClear(false); }}>
        <section className="confirm-card" role="dialog" aria-modal="true" aria-labelledby="clear-title" data-testid="dialog-clear-chat">
          <h2 id="clear-title">Очистить историю?</h2>
          <p>Все сообщения будут удалены с этого устройства. Это действие нельзя отменить.</p>
          <div className="confirm-actions">
            <button onClick={() => setShowClear(false)} data-testid="button-cancel-clear">Оставить</button>
            <button className="danger" onClick={() => { requestSequence.current += 1; sending.current = false; chatMutation.reset(); setChatError(null); setMessages([]); setShowClear(false); }} data-testid="button-confirm-clear">Очистить историю</button>
          </div>
        </section>
      </div>}
    </AppFrame>
  );
}

function SettingsPage({ settings, setSettings, messages, onClear, aiConfigured }: {
  settings: AssistantSettings;
  setSettings: (next: AssistantSettings) => void;
  messages: ChatMessage[];
  onClear: () => void;
  aiConfigured?: boolean;
}) {
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [speechAvailable, setSpeechAvailable] = useState(false);
  useEffect(() => {
    const loadVoices = () => setVoices(window.speechSynthesis?.getVoices().filter(voice => voice.lang.toLowerCase().startsWith('ru')) ?? []);
    setSpeechAvailable('speechSynthesis' in window);
    loadVoices();
    window.speechSynthesis?.addEventListener('voiceschanged', loadVoices);
    return () => window.speechSynthesis?.removeEventListener('voiceschanged', loadVoices);
  }, []);
  const update = (partial: Partial<AssistantSettings>) => setSettings({ ...settings, ...partial });
  return (
    <section className="settings-page" aria-labelledby="settings-title">
      <div className="settings-heading">
        <div className="eyebrow">ПЕРСОНАЛИЗАЦИЯ · 02</div>
        <h1 id="settings-title">Настройки</h1>
        <p>Настройте голосовой интерфейс и подключение ИИ. Локальные параметры сохраняются в этом браузере.</p>
      </div>
      <div className="settings-group-title">Подключение ИИ</div>
      <section className="ai-setup-card" aria-label="Настройка DeepSeek" data-testid="card-ai-setup">
        <div className="ai-setup-status">
          <span className={`connection-indicator ${aiConfigured ? 'on' : ''}`} aria-hidden="true" />
          <strong>{aiConfigured ? 'DeepSeek подключён' : 'DeepSeek не подключён'}</strong>
        </div>
        {!aiConfigured && (
          <ol>
            <li><a href="https://platform.deepseek.com/api_keys" target="_blank" rel="noreferrer">Создайте API-ключ в кабинете DeepSeek</a>.</li>
            <li>В Replit откройте «Инструменты» → Setup → Secrets → New Secret.</li>
            <li>Укажите имя <code>DEEPSEEK_API_KEY</code>, вставьте ключ в поле значения и сохраните.</li>
            <li>Перезапустите workflow «API Server» в панели Workflows. Затем обновите эту страницу.</li>
          </ol>
        )}
        <p className="ai-cost-note">Используется DeepSeek Flash. Вне пиковых часов: $0,15 за 1 млн входных токенов без кэш-попадания и $0,60 за 1 млн выходных; в пиковые часы тариф выше, входные данные из кэша дешевле. Оплата списывается с баланса DeepSeek API; длинная история диалога увеличивает расход.</p>
        <a className="pricing-link" href="https://api-docs.deepseek.com/quick_start/pricing" target="_blank" rel="noreferrer">Проверить актуальные тарифы DeepSeek</a>
      </section>
      <div className="settings-group-title">Голосовой интерфейс</div>
      <div className="setting-row">
        <div className="setting-copy"><strong>Озвучивать ответы</strong><span>Использовать синтез речи браузера</span></div>
        <button className="toggle" role="switch" aria-checked={settings.speechEnabled} aria-label="Озвучивать ответы" onClick={() => update({ speechEnabled: !settings.speechEnabled })} data-testid="switch-speech-output" />
      </div>
      <div className="setting-row">
        <div className="setting-copy"><strong>Скорость речи</strong><span>Темп озвучивания ответов JARVIS</span></div>
        <div className="setting-control range-wrap">
          <input type="range" min="0.7" max="1.3" step="0.1" value={settings.speechRate} onChange={event => update({ speechRate: Number(event.target.value) })} aria-label="Скорость речи" data-testid="input-speech-rate" />
          <span className="range-value" data-testid="text-speech-rate">{settings.speechRate.toFixed(1)}×</span>
        </div>
      </div>
      <div className="setting-row">
        <div className="setting-copy"><strong>Голос</strong><span>{speechAvailable ? (voices.length ? 'Доступные голоса браузера для русского языка' : 'Голоса загружаются или не установлены') : 'Синтез речи не поддерживается браузером'}</span></div>
        <label className="setting-control">
          <span className="sr-only">Голос озвучивания</span>
          <select value={settings.voiceURI} onChange={event => update({ voiceURI: event.target.value })} disabled={!voices.length} aria-label="Голос озвучивания" data-testid="select-speech-voice">
            <option value="">По умолчанию</option>
            {voices.map(voice => <option key={voice.voiceURI} value={voice.voiceURI}>{voice.name}{voice.default ? ' · основной' : ''}</option>)}
          </select>
        </label>
      </div>
      <div className="settings-group-title">Данные на устройстве</div>
      <div className="setting-row">
        <div className="setting-copy"><strong>История диалога</strong><span>{messages.length ? `${messages.length} сообщений сохранено локально` : 'История пока пуста'}</span></div>
        <button className="quiet-button" onClick={onClear} disabled={!messages.length} aria-label="Очистить историю диалога" data-testid="button-clear-chat">
          <Trash2 aria-hidden="true" /><span>Очистить</span>
        </button>
      </div>
      <div className="settings-note" role="note" data-testid="text-privacy-note">
        <Shield aria-hidden="true" />
         <span><strong>Приватность.</strong> История и настройки сохраняются в локальном хранилище этого браузера. При отправке сообщения текст и контекст диалога передаются DeepSeek API для ответа. Ключ остаётся на сервере и не попадает в браузер или логи. Голосовой ввод может обрабатываться службой распознавания браузера.</span>
      </div>
    </section>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/settings" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
