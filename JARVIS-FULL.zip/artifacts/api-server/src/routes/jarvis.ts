import { recordJarvisUsage, calculateJarvisCost } from "../lib/jarvis-budget";
import { reserveJarvisBudget, releaseJarvisBudget, settleJarvisBudget, RESERVE_PER_REQUEST_USD } from "../lib/jarvis-budget";
import { pool } from "@workspace/db";
import { Router, type IRouter, type Response } from "express";
import {
  GetJarvisStatusResponse,
  SendJarvisChatMessageBody,
  SendJarvisChatMessageResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();
const DEEPSEEK_CHAT_URL = "https://api.deepseek.com/chat/completions";
const MAX_COMPLETION_TOKENS = 1024;
const RATE_WINDOW_MS = 60_000;
const RATE_LIMIT = 10;
const rateBuckets = new Map<string, { count: number; expiresAt: number }>();

const systemPrompt =
  "Ты JARVIS — персональный ИИ-ассистент. Отвечай по-русски, если пользователь не попросил другой язык. Будь полезным, точным и честным: не утверждай, что выполнил действия вне этого чата.";

function consumeRateLimit(clientIp: string): boolean {
  const now = Date.now();
  const current = rateBuckets.get(clientIp);

  if (!current || current.expiresAt <= now) {
    rateBuckets.set(clientIp, { count: 1, expiresAt: now + RATE_WINDOW_MS });
  } else if (current.count >= RATE_LIMIT) {
    return false;
  } else {
    current.count += 1;
  }

  if (rateBuckets.size > 1_000) {
    for (const [ip, bucket] of rateBuckets) {
      if (bucket.expiresAt <= now) rateBuckets.delete(ip);
    }
  }

  return true;
}

function sendError(
  res: Response,
  status: number,
  code: string,
  message: string,
): void {
  res.status(status).json({ error: { code, message } });
}

router.get("/jarvis/status", (_req, res): void => {
  res.json(
    GetJarvisStatusResponse.parse({
      configured: Boolean(process.env.DEEPSEEK_API_KEY?.trim()),
    }),
  );
});

router.post("/jarvis/chat", async (req, res): Promise<void> => {
  const clientIp = req.ip || req.socket.remoteAddress || "unknown";
  if (!consumeRateLimit(clientIp)) {
    sendError(
      res,
      429,
      "RATE_LIMITED",
      "Слишком много запросов подряд. Подождите минуту и попробуйте снова.",
    );
    return;
  }

  const parsed = SendJarvisChatMessageBody.safeParse(req.body);
  if (!parsed.success) {
    sendError(
      res,
      400,
      "INVALID_CHAT",
      "Не удалось проверить сообщение. Убедитесь, что история диалога не слишком длинная.",
    );
    return;
  }

  if (parsed.data.messages.at(-1)?.role !== "user") {
    sendError(
      res,
      400,
      "MISSING_USER_MESSAGE",
      "Перед отправкой добавьте новое сообщение.",
    );
    return;
  }

  const apiKey = process.env.DEEPSEEK_API_KEY?.trim();
  if (!apiKey) {
    sendError(
      res,
      503,
      "AI_NOT_CONFIGURED",
      "Реальные ответы ИИ пока не подключены. В Replit откройте Tools → Setup → Secrets → New Secret, добавьте DEEPSEEK_API_KEY и перезапустите workflow API Server. Запросы тарифицируются DeepSeek API.",
    );
    return;
  }

  try {
    const providerResponse = await fetch(DEEPSEEK_CHAT_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "deepseek-flash",
        thinking: { type: "disabled" },
        messages: [
          { role: "system", content: systemPrompt },
          ...parsed.data.messages,
        ],
        max_tokens: MAX_COMPLETION_TOKENS,
      }),
      signal: AbortSignal.timeout(45_000),
    });

    if (!providerResponse.ok) {
      req.log.warn(
        { status: providerResponse.status },
        "DeepSeek chat request was rejected",
      );

      if (providerResponse.status === 401 || providerResponse.status === 403) {
        sendError(
          res,
          503,
          "AI_KEY_REJECTED",
          "DeepSeek не принял ключ. Проверьте секрет DEEPSEEK_API_KEY в Replit Secrets.",
        );
        return;
      }

      if (providerResponse.status === 402) {
        sendError(
          res,
          503,
          "AI_PROVIDER_BALANCE",
          "Баланс DeepSeek API исчерпан или недостаточен. Проверьте баланс и тарифы в кабинете DeepSeek.",
        );
        return;
      }

      if (providerResponse.status === 429) {
        sendError(
          res,
          429,
          "AI_PROVIDER_LIMIT",
          "DeepSeek временно отклонил запрос из-за лимита. Подождите и попробуйте снова.",
        );
        return;
      }

      sendError(
        res,
        providerResponse.status >= 500 ? 503 : 502,
        "AI_PROVIDER_ERROR",
        "Сервис ИИ не смог обработать запрос. Попробуйте позже.",
      );
      return;
    }

    const data = (await providerResponse.json()) as {
      usage?: {
        prompt_tokens?: number;
        completion_tokens?: number;
        prompt_cache_hit_tokens?: number;
        prompt_cache_miss_tokens?: number;
      };
      choices?: Array<{ message?: { content?: string | null } }>;
    };
    const text = data.choices?.[0]?.message?.content?.trim();

    if (!text) {
      req.log.warn("DeepSeek returned an empty chat response");
      sendError(
        res,
        502,
        "AI_EMPTY_RESPONSE",
        "Сервис ИИ вернул пустой ответ. Попробуйте отправить сообщение ещё раз.",
      );
      return;
    }


    if (data.usage) {
      try {
        const costUsd = calculateJarvisCost(data.usage);
        await recordJarvisUsage(costUsd);

        const budgetResult = await pool.query(
          `SELECT spent_usd FROM jarvis_monthly_usage
           WHERE month = $1`,
          [new Date().toISOString().slice(0, 7)]
        );

        const spentUsd = Number(budgetResult.rows[0]?.spent_usd ?? 0);

        if (spentUsd >= 5) {
          req.log.warn(
            { spentUsd },
            "JARVIS: месячный бюджет $5 превышен"
          );
        } else if (spentUsd >= 4) {
          req.log.warn(
            { spentUsd },
            "JARVIS: расходы приближаются к $5"
          );
        }
      } catch (usageError) {
        req.log.error(
          { error: usageError },
          "Failed to record JARVIS usage"
        );
      }
    }

    res.json(SendJarvisChatMessageResponse.parse({ text }));
  } catch (error) {
    req.log.error(
      { errorName: error instanceof Error ? error.name : "UnknownError" },
      "DeepSeek chat request failed",
    );
    sendError(
      res,
      503,
      "AI_UNAVAILABLE",
      "Не удалось связаться с сервисом ИИ. Проверьте подключение и попробуйте позже.",
    );
  }
});

export default router;

router.get("/jarvis/budget", async (req, res) => {
  try {
    const month = new Date().toISOString().slice(0, 7);
    const result = await pool.query(
      `SELECT spent_usd FROM jarvis_monthly_usage WHERE month = $1`,
      [month]
    );

    const spentUsd = Number(result.rows[0]?.spent_usd ?? 0);

    res.json({
      month,
      spentUsd,
      budgetUsd: 5,
      remainingUsd: Math.max(0, 5 - spentUsd),
      percentage: Math.round((spentUsd / 5) * 100),
      exceeded: spentUsd >= 5,
      mode: "soft"
    });
  } catch (error) {
    req.log.error({ error }, "Failed to load JARVIS budget");
    res.status(500).json({ error: "BUDGET_UNAVAILABLE" });
  }
});
