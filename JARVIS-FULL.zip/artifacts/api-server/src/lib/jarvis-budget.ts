import { pool } from "@workspace/db";

export const MONTHLY_BUDGET_USD = 5;
export const RESERVE_PER_REQUEST_USD = 0.05;

export async function reserveJarvisBudget(): Promise<string | null> {
  const month = new Date().toISOString().slice(0, 7);
  const result = await pool.query(
    `INSERT INTO jarvis_monthly_usage (month, spent_usd, reserved_usd, updated_at)
     SELECT $1, 0, $2, NOW() WHERE $2 <= $3
     ON CONFLICT (month) DO UPDATE SET
       reserved_usd = jarvis_monthly_usage.reserved_usd + $2,
       updated_at = NOW()
     WHERE jarvis_monthly_usage.spent_usd + jarvis_monthly_usage.reserved_usd + $2 <= $3
     RETURNING month`,
    [month, RESERVE_PER_REQUEST_USD, MONTHLY_BUDGET_USD]
  );
  return (result.rowCount ?? 0) > 0 ? month : null;
}

export async function releaseJarvisBudget(month: string, amountUsd: number): Promise<void> {
  if (!/^\d{4}-\d{2}$/.test(month) || !Number.isFinite(amountUsd) || amountUsd <= 0) {
    throw new Error("Invalid budget release arguments");
  }
  const result = await pool.query(
    `UPDATE jarvis_monthly_usage
     SET reserved_usd = reserved_usd - $2,
         updated_at = NOW()
     WHERE month = $1 AND reserved_usd >= $2`,
    [month, amountUsd]
  );
  if (result.rowCount !== 1) {
    throw new Error("Budget reservation could not be released");
  }
}

export async function settleJarvisBudget(
  month: string,
  reservedUsd: number,
  actualUsd: number
): Promise<void> {
  if (!/^\d{4}-\d{2}$/.test(month) ||
      !Number.isFinite(reservedUsd) || reservedUsd <= 0 ||
      !Number.isFinite(actualUsd) || actualUsd < 0) {
    throw new Error("Invalid budget settlement arguments");
  }
  if (actualUsd > reservedUsd) {
    throw new Error("Actual cost exceeds reserved budget");
  }
  const result = await pool.query(
    `UPDATE jarvis_monthly_usage
     SET reserved_usd = reserved_usd - $2,
         spent_usd = spent_usd + $3,
         updated_at = NOW()
     WHERE month = $1 AND reserved_usd >= $2`,
    [month, reservedUsd, actualUsd]
  );
  if (result.rowCount !== 1) {
    throw new Error("Budget settlement failed");
  }
}

export async function recordJarvisUsage(
  costUsd: number
): Promise<void> {
  if (!Number.isFinite(costUsd) || costUsd < 0) {
    throw new Error("Invalid usage cost");
  }

  const month = new Date().toISOString().slice(0, 7);

  await pool.query(
    `INSERT INTO jarvis_monthly_usage
       (month, spent_usd, reserved_usd, updated_at)
     VALUES ($1, $2, 0, NOW())
     ON CONFLICT (month) DO UPDATE SET
       spent_usd = jarvis_monthly_usage.spent_usd + $2,
       updated_at = NOW()`,
    [month, costUsd]
  );
}

export function calculateJarvisCost(usage: {
  prompt_tokens?: number;
  completion_tokens?: number;
  prompt_cache_hit_tokens?: number;
  prompt_cache_miss_tokens?: number;
}): number {
  const input = usage.prompt_tokens ?? 0;
  const output = usage.completion_tokens ?? 0;
  const hits = Math.min(
    usage.prompt_cache_hit_tokens ?? 0,
    input
  );
  const misses = input - hits;

  const cost =
    (hits / 1_000_000) * 0.07 +
    (misses / 1_000_000) * 0.27 +
    (output / 1_000_000) * 1.10;

  return Math.round(cost * 1_000_000) / 1_000_000;
}
